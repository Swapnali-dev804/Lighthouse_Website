﻿Lighthouse Learning Hub - placeholder source code bundle.
Replace assets/downloads/source-code.zip with your real course code archive.
